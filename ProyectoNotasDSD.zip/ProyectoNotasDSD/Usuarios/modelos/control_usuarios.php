<?php

if($_POST['txtNombre'] == "Dilan" && $_POST['txtcontrasena'] == "12345" )
{
    session_start();
    //definara las variables de sesion
    $_SESSION['usuario']=$_POST['txtNombre'];
    $_SESSION['validacion']= true;
    $_SESSION['start']=time();
    $_SESSION['expire']= $_SESSION['start']+(1*6);

    header("Location: ../../Administrador/pages/index.php");
}else
{
    echo"<script>
    alert('datos incorrectos');window.location='../../index.php';
    </script>";
}

?>